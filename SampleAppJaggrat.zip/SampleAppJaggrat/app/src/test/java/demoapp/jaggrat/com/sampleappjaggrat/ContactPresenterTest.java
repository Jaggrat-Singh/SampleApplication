package demoapp.jaggrat.com.sampleappjaggrat;

import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import demoapp.jaggrat.com.sampleappjaggrat.interfaces.IContactPresenter;
import demoapp.jaggrat.com.sampleappjaggrat.models.ContactModel;
import demoapp.jaggrat.com.sampleappjaggrat.presenter.ContactPresenter;

/**
 * Created by jsin67 on 5/21/2017.
 */

public class ContactPresenterTest {

    @Test
    public void testProcessList(){
        IContactPresenter contactPresenter = new ContactPresenter();

        List<ContactModel> list = contactPresenter.processList(getDummyList());
        Assert.assertEquals(0, list.size());
    }

    private List<ContactModel> getDummyList(){
        List<ContactModel> contactModelList = new ArrayList<>();

        for (int i = 0 ; i < 3; i++){
            ContactModel contactModel  = new ContactModel();
            contactModel.setName("name" + i);
            contactModel.setUId(i);
            contactModel.setDelete(true);
            contactModelList.add(contactModel);
        }
        return contactModelList;
    }


    @Test
    public void deleteContactTest(){
        IContactPresenter contactPresenter = new ContactPresenter();
        List<ContactModel> dummyList = getDummyList();
        contactPresenter.deleteContact(dummyList, null );
        Assert.assertEquals(dummyList.size(),getDummyList().size());
    }

    @Test
    public void filterListTest(){
        IContactPresenter contactPresenter = new ContactPresenter();
        List<ContactModel> serverList = getServerList();
        serverList.add(new ContactModel("jaggrat", 123));
        List<ContactModel> dbList = getDummyList();
        List<ContactModel> filteredList = contactPresenter.filterList(serverList, dbList);

        Assert.assertEquals(1, filteredList.size());
        Assert.assertEquals("jaggrat", filteredList.get(0).getName());
        Assert.assertEquals(123, filteredList.get(0).getUId());

        filteredList = contactPresenter.filterList(null , dbList);
        Assert.assertNotNull(filteredList);
        Assert.assertEquals(0, filteredList.size());

        filteredList = contactPresenter.filterList(serverList, null);
        Assert.assertNotNull(filteredList);
        Assert.assertEquals(4, filteredList.size());

    }

    private List<ContactModel> getServerList(){
        List<ContactModel> contactModelList = new ArrayList<>();

        for (int i = 0 ; i < 3; i++){
            ContactModel contactModel  = new ContactModel();
            contactModel.setName("name" + i);
            contactModel.setUId(i);
            contactModel.setDelete(false);
            contactModelList.add(contactModel);
        }
        return contactModelList;
    }
}
