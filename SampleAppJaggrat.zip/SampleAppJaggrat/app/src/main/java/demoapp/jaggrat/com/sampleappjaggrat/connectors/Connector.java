package demoapp.jaggrat.com.sampleappjaggrat.connectors;

import android.text.TextUtils;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import demoapp.jaggrat.com.sampleappjaggrat.constant.AppConstant;
import demoapp.jaggrat.com.sampleappjaggrat.models.ContactModel;

/**
 * Contains server and parsing logic.
 */

class Connector {

    /**
     * Get all contacts from server.
     *
     * @return : List.
     */
    protected List<ContactModel> fetchContactList() {
        return connectToServer();
    }

    /**
     * Connects to server.
     *
     * @return : List of model.
     */
    private List<ContactModel> connectToServer() {
        List<ContactModel> contactModelList = new ArrayList<>();
        URL url = null;
        HttpURLConnection urlConnection = null;
        try {
            url = new URL(AppConstant.URL);
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setConnectTimeout(20 * 1000);
            urlConnection.setRequestProperty(AppConstant.KEY_TOKEN, AppConstant.TOKEN);
            InputStream in = new BufferedInputStream(urlConnection.getInputStream());
            String jsonStr = readStream(in);
            if (!TextUtils.isEmpty(jsonStr)) {
                contactModelList = getContactListFromJson(validateJsonResponse(jsonStr));
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
        }
        return contactModelList;
    }

    /**
     * Checks for valid and success message from server.
     *
     * @param json : Json str.
     * @return : valid json contacts.
     */
    private String validateJsonResponse(String json) {
        String contactArrayJson = null;
        try {
            JSONObject jsonObject = new JSONObject(json);
            String status = (String) jsonObject.get(AppConstant.STATUS);
            if (status.equals(AppConstant.SUCCESS)) {
                JSONArray jsonArray = jsonObject.getJSONArray(AppConstant.RESULT);
                contactArrayJson = jsonArray.toString();
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return contactArrayJson;
    }

    /**
     * Reads input stream.
     *
     * @param inputStream : Input stream.
     * @return
     * @throws IOException : Execption
     */
    private String readStream(InputStream inputStream) throws IOException {
        final BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        StringBuilder total = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            total.append(line);
        }
        if (reader != null) {
            reader.close();
        }
        return total.toString();
    }

    /**
     * Converts json to contact list.
     *
     * @param json : Json str
     * @return : List of all Contact model.
     */
    private List<ContactModel> getContactListFromJson(String json) {
        List<ContactModel> contactModelList = new ArrayList<>();
        if (!TextUtils.isEmpty(json)) {
            Gson gson = new Gson();
            ContactModel[] contactModels = gson.fromJson(json, ContactModel[].class);
            contactModelList = Arrays.asList(contactModels);
        }
        return contactModelList;
    }
}
