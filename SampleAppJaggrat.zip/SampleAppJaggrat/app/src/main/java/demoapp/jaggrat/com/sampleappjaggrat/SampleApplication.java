package demoapp.jaggrat.com.sampleappjaggrat;

import android.app.Application;

import demoapp.jaggrat.com.sampleappjaggrat.database.ContactsDataSource;

/**
 * Created by jsin67 on 5/21/2017.
 */

public class SampleApplication extends Application {

    public static void setContactsDataSource(ContactsDataSource mMySQLiteHelper) {
        SampleApplication.mContactsDataSource = mMySQLiteHelper;
    }

    private static ContactsDataSource mContactsDataSource;

    @Override
    public void onCreate() {
        super.onCreate();
        mContactsDataSource = new ContactsDataSource(getApplicationContext());
    }

    public static ContactsDataSource getMySQLiteHelper() {
        return mContactsDataSource;
    }

    public static void clearSqlHelper() {
        mContactsDataSource = null;
    }
}
