package demoapp.jaggrat.com.sampleappjaggrat.connectors;

import android.os.AsyncTask;

import java.util.List;

import demoapp.jaggrat.com.sampleappjaggrat.SampleApplication;
import demoapp.jaggrat.com.sampleappjaggrat.database.ContactsDataSource;
import demoapp.jaggrat.com.sampleappjaggrat.interfaces.IContactPresenter;
import demoapp.jaggrat.com.sampleappjaggrat.interfaces.IContactsCallback;
import demoapp.jaggrat.com.sampleappjaggrat.models.ContactModel;

/**
 * Thread to download data from server and merge data with DB items.
 */

public class FetchContactList extends AsyncTask<Void, String, List<ContactModel>> {

    private IContactsCallback iContactsCallback;
    private IContactPresenter contactPresenter;

    public FetchContactList(IContactsCallback iContactsCallback, IContactPresenter
            contactPresenter) {
        this.iContactsCallback = iContactsCallback;
        this.contactPresenter = contactPresenter;

    }

    @Override
    protected List<ContactModel> doInBackground(Void... params) {
        ContactsDataSource contactsDataSource = SampleApplication.getMySQLiteHelper();
        Connector connector = new Connector();
        List<ContactModel> serverModelList = connector.fetchContactList();
        if(serverModelList != null && !serverModelList.isEmpty()){
            List<ContactModel> databaseModelList = contactPresenter.getContacts();
            List<ContactModel> filteredList = contactPresenter.filterList(serverModelList, databaseModelList);
            contactsDataSource.insertContacts(filteredList);
        }

        return contactsDataSource.getAllContacts();
    }

    @Override
    protected void onPostExecute(List<ContactModel> contactModelList) {
        super.onPostExecute(contactModelList);
        iContactsCallback.contactsDownloaded(contactModelList);
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }
}
