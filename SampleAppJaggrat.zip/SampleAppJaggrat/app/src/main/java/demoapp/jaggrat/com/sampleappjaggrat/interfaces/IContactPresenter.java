package demoapp.jaggrat.com.sampleappjaggrat.interfaces;

import java.util.List;

import demoapp.jaggrat.com.sampleappjaggrat.models.ContactModel;

/**
 * Features for contacts.
 */
public interface IContactPresenter {

    /**
     * Delete contact from list
     * @param contactModelList :List of contact
     * @param contactModel : Model to delete from list.
     */
    void deleteContact(List<ContactModel> contactModelList , ContactModel contactModel);

    /**
     * Retrieves all contact.
     * @return : List
     */
    List<ContactModel> getContacts();

    /**
     * Returns fresh contact list.
     * @param listFromServer : List from server;
     * @param listFromDatabase : List from db.
     * @return : Filtered list.
     */
    List<ContactModel> filterList(List<ContactModel> listFromServer, List<ContactModel> listFromDatabase);

    /**
     * Remove all deleted items from list.
     * @param contactModelList : List.
     * @return : Non-deleted item list.
     */
    List<ContactModel> processList(List<ContactModel> contactModelList);
}
