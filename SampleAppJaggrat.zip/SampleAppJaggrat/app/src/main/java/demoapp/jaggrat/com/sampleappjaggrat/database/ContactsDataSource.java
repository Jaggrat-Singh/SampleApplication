package demoapp.jaggrat.com.sampleappjaggrat.database;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import demoapp.jaggrat.com.sampleappjaggrat.SampleApplication;
import demoapp.jaggrat.com.sampleappjaggrat.constant.AppConstant;
import demoapp.jaggrat.com.sampleappjaggrat.models.ContactModel;

public class ContactsDataSource {

    // Database fields
    private SQLiteDatabase database;
    private MySQLiteHelper dbHelper;
    private String[] allColumns = {MySQLiteHelper.COLUMN_ID,
            MySQLiteHelper.COLUMN_UID, MySQLiteHelper.COLUMN_NAME, MySQLiteHelper.COLUMN_DELETE};

    public ContactsDataSource(Context context) {
        dbHelper = MySQLiteHelper.createDBInstance(context);
        open();
    }

    public void open() throws SQLException {
        if(dbHelper != null){
            database = dbHelper.getWritableDatabase();
        }
    }

    public void close() {
        dbHelper.close();
    }

    public boolean deleteContact(ContactModel contactModel) {
        long id = contactModel.getUId();
        System.out.println("Contact deleted with id: " + id);
        ContentValues contentValues = new ContentValues();
        contentValues.put(MySQLiteHelper.COLUMN_DELETE, AppConstant.DELETE_KEY);
        contentValues.put(MySQLiteHelper.COLUMN_NAME, contactModel.getName());
        contentValues.put(MySQLiteHelper.COLUMN_ID, contactModel.getRowId());
        contentValues.put(MySQLiteHelper.COLUMN_UID, contactModel.getUId());
        return database.update(MySQLiteHelper.TABLE_CONTACT, contentValues, MySQLiteHelper
                .COLUMN_UID
                + " = " + id, null) > 0;
    }

    /**
     * Returns all record.
     * @return List of models.
     */
    public List<ContactModel> getAllContacts() {
        List<ContactModel> modelArrayList = new ArrayList<>();

        Cursor cursor = database.query(MySQLiteHelper.TABLE_CONTACT,
                allColumns, null, null, null, null, null);

        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            ContactModel comment = cursorToContact(cursor);
            modelArrayList.add(comment);
            cursor.moveToNext();
        }
        // make sure to close the cursor
        cursor.close();
        return modelArrayList;
    }

    /**
     * Inserts the record in DB.
     * @param contactModelList : List of model
     * @return: Status
     */
    public boolean insertContacts(List<ContactModel> contactModelList) {
        long id = -1;
        if(database == null ){
            return false;
        }
        database.beginTransaction();
        try {
            ContentValues values = new ContentValues();
            for (ContactModel contactModel : contactModelList) {
                values.put(MySQLiteHelper.COLUMN_UID, contactModel.getUId());
                values.put(MySQLiteHelper.COLUMN_NAME, contactModel.getName());
                values.put(MySQLiteHelper.COLUMN_DELETE, contactModel.isDeleted() ? AppConstant
                        .DELETE_KEY : AppConstant.NOT_DELETE_KEY);
                id = database.insert(MySQLiteHelper.TABLE_CONTACT, null, values);
            }
            database.setTransactionSuccessful();
        } finally {
            database.endTransaction();
        }

        return id > 0;
    }

    /**
     * Converts cursor to contact.
     * @param cursor Cursor
     * @return : Model
     */
    private ContactModel cursorToContact(Cursor cursor) {
        ContactModel contactModel = new ContactModel();
        contactModel.setRowId(cursor.getInt(0));
        contactModel.setName(cursor.getString(2));
        contactModel.setDelete(cursor.getString(3).equals(AppConstant.DELETE_KEY));
        contactModel.setUId(cursor.getInt(1));
        return contactModel;
    }
}