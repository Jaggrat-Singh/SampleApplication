package demoapp.jaggrat.com.sampleappjaggrat.presenter;

import java.util.ArrayList;
import java.util.List;

import demoapp.jaggrat.com.sampleappjaggrat.SampleApplication;
import demoapp.jaggrat.com.sampleappjaggrat.database.ContactsDataSource;
import demoapp.jaggrat.com.sampleappjaggrat.interfaces.IContactPresenter;
import demoapp.jaggrat.com.sampleappjaggrat.models.ContactModel;

/**
 * Concrete implementation.
 */

public class ContactPresenter implements IContactPresenter {

    @Override
    public void deleteContact(List<ContactModel> contactModelList, ContactModel contactModel) {
        boolean status ;
        if(contactModelList != null && !contactModelList.isEmpty() && contactModel != null){
            ContactsDataSource contactsDataSource  = SampleApplication.getMySQLiteHelper();
            status = contactsDataSource.deleteContact(contactModel);
            if(status){
                contactModelList.remove(contactModel);
            }
        }
    }

    @Override
    public List<ContactModel> getContacts() {
        ContactsDataSource contactPresenter = SampleApplication.getMySQLiteHelper();
        return contactPresenter.getAllContacts();
    }

    @Override
    public List<ContactModel> filterList(List<ContactModel> listFromServer, List<ContactModel> listFromDatabase) {
        List<ContactModel> filteredList = new ArrayList<>();
        boolean status = false;
        //check if there is no entry in database and return list from server to be inserted in DB.
        if(listFromDatabase == null || listFromDatabase.isEmpty()){
            return listFromServer;
        }
        //check if list from server is empty and return EMPTY list because there would be no DB operation.
        if(listFromServer == null || listFromServer.isEmpty()){
            return filteredList;
        }

        //now we have both the list, check for non-existent item in DB so that we can insert it.
        for (int i = 0; i < listFromServer.size(); i++) {
            ContactModel serverModel = listFromServer.get(i);
            for (int j = 0; j < listFromDatabase.size(); j++) {
                ContactModel databaseModel = listFromDatabase.get(j);
                if (serverModel.getName().equals(databaseModel.getName()) && serverModel.getUId() == databaseModel.getUId()) {
                    status = false;
                    break;
                } else {
                    status = true;
                }
            }
            if(status){
                filteredList.add(serverModel);
                status = false;
            }
        }
        return filteredList;
    }

    @Override
    public List<ContactModel> processList(List<ContactModel> contactModelList) {
        List<ContactModel> modelList = new ArrayList<>();
        for (ContactModel contactModel : contactModelList){
            if(!contactModel.isDeleted()){
                modelList.add(contactModel);
            }
        }
        return modelList;
    }
}
