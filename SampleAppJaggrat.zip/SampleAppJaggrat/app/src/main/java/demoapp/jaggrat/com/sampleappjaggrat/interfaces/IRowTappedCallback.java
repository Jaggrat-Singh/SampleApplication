package demoapp.jaggrat.com.sampleappjaggrat.interfaces;

/**
 * Created by jsin67 on 5/21/2017.
 */

public interface IRowTappedCallback {
    /**
     * Called when row is tapped.
     * @param position : Position
     */
    void deleteItemTapped(int position);
}
