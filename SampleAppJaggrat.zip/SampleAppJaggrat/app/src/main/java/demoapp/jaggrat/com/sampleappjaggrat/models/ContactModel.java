package demoapp.jaggrat.com.sampleappjaggrat.models;

import com.google.gson.annotations.SerializedName;

/**
 * Data Model for contact.
 */

public class ContactModel {
    @SerializedName("name")
    private String mName;
    @SerializedName("uid")
    private int mId;
    private boolean IsDelete;
    private int rowId;
    public ContactModel() {
    }

    public int getRowId() {
        return rowId;
    }

    public void setRowId(int rowId) {
        this.rowId = rowId;
    }

    public void setName(String mName) {
        this.mName = mName;
    }

    public void setUId(int mId) {
        this.mId = mId;
    }

    public void setDelete(boolean delete) {
        IsDelete = delete;
    }

    public ContactModel(String mName, int mId) {
        this.mName = mName;
        this.mId = mId;
    }

    public int getUId() {
        return mId;
    }


    public ContactModel(String name, String isDeleted, String mId) {
        this.mName = name;
        this.IsDelete = IsDelete;
    }

    public String getName() {
        return mName;
    }

    public boolean isDeleted() {
        return IsDelete;
    }
}
