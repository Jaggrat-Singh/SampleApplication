package demoapp.jaggrat.com.sampleappjaggrat.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import java.util.List;

import demoapp.jaggrat.com.sampleappjaggrat.R;
import demoapp.jaggrat.com.sampleappjaggrat.interfaces.IRowTappedCallback;
import demoapp.jaggrat.com.sampleappjaggrat.models.ContactModel;

/**
 * Adapter to show data on UI.
 */

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.CustomViewHolder> implements View.OnClickListener{

    private List<ContactModel> itemList;
    private IRowTappedCallback iRowTappedCallback;
    public CustomAdapter(List<ContactModel> items, IRowTappedCallback rowTappedCallback) {
        itemList = items;
        iRowTappedCallback = rowTappedCallback;
    }

    static class CustomViewHolder extends RecyclerView.ViewHolder {
        TextView tvName;
        Button btnDelete;

        CustomViewHolder(View row) {
            super(row);
        }
    }

    @Override
    public CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View rowView = layoutInflater.inflate(R.layout.row_layout, parent, false);
        TextView name = (TextView) rowView.findViewById(R.id.tv_name);
        Button delete = (Button) rowView.findViewById(R.id.btn_delete);
        CustomViewHolder customViewHolder = new CustomViewHolder(rowView);
        customViewHolder.tvName = name;
        customViewHolder.btnDelete = delete;
        return customViewHolder;
    }

    @Override
    public void onBindViewHolder(CustomViewHolder holder, int position) {
        holder.tvName.setText(itemList.get(position).getName());
        holder.btnDelete.setOnClickListener(this);
        holder.btnDelete.setTag(position);
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    @Override
    public void onClick(View v) {
        int item = (int) v.getTag();
        iRowTappedCallback.deleteItemTapped(item);
    }
}
