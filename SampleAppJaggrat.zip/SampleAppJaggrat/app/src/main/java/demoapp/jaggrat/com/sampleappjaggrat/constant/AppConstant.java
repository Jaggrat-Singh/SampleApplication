package demoapp.jaggrat.com.sampleappjaggrat.constant;

/**
 * App Constant
 */

public class AppConstant {

    public static String URL = "http://139.162.152.157/contactlist.php";
    public static String TOKEN = "c149c4fac72d3a3678eefab5b0d3a85a";
    public static String DELETE_KEY = "delete";
    public static String NOT_DELETE_KEY = "not_delete";
    public static String KEY_TOKEN = "token";
    public static String STATUS = "status";
    public static String MESSAGE = "token";
    public static String SUCCESS = "success";
    public static String RESULT = "result";
}
