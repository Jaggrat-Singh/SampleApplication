package demoapp.jaggrat.com.sampleappjaggrat.interfaces;

import java.util.List;

import demoapp.jaggrat.com.sampleappjaggrat.models.ContactModel;

/**
 * Created by jsin67 on 5/21/2017.
 */

public interface IContactsCallback {
    /**
     * Called when contacts is downloaded.
     * @param contactModelList : List of models.
     */
    public void contactsDownloaded(List<ContactModel> contactModelList);
}
