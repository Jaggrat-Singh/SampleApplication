package demoapp.jaggrat.com.sampleappjaggrat.userinterface;

import android.app.ProgressDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import java.util.List;

import demoapp.jaggrat.com.sampleappjaggrat.R;
import demoapp.jaggrat.com.sampleappjaggrat.SampleApplication;
import demoapp.jaggrat.com.sampleappjaggrat.adapter.CustomAdapter;
import demoapp.jaggrat.com.sampleappjaggrat.connectors.FetchContactList;
import demoapp.jaggrat.com.sampleappjaggrat.database.ContactsDataSource;
import demoapp.jaggrat.com.sampleappjaggrat.interfaces.IContactPresenter;
import demoapp.jaggrat.com.sampleappjaggrat.interfaces.IContactsCallback;
import demoapp.jaggrat.com.sampleappjaggrat.interfaces.IRowTappedCallback;
import demoapp.jaggrat.com.sampleappjaggrat.models.ContactModel;
import demoapp.jaggrat.com.sampleappjaggrat.presenter.ContactPresenter;

/**
 * UI for contact list.
 */
public class ContactsActivity extends AppCompatActivity implements IContactsCallback,
        IRowTappedCallback {
    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private List<ContactModel> mContactModelList;
    private IContactPresenter mContactPresenter;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_items);
        mContactPresenter = new ContactPresenter();
        mRecyclerView = (RecyclerView) findViewById(R.id.my_recycler_view);
        mRecyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(layoutManager);
    }

    @Override
    protected void onStart() {
        super.onStart();
        ContactsDataSource contactsDataSource = new ContactsDataSource(getApplicationContext());
        SampleApplication.setContactsDataSource(contactsDataSource);
        if (isNetworkAvailable()) {
            progressDialog = showDialog(getString(R.string.loading));
            FetchContactList fetchContactList = new FetchContactList(this, mContactPresenter);
            fetchContactList.execute();
        } else {

            List<ContactModel> contacts = mContactPresenter.getContacts();
            if(contacts != null && !contacts.isEmpty()){
                mContactModelList = mContactPresenter.processList(contacts);
                mAdapter = new CustomAdapter(mContactModelList, this);
                mRecyclerView.setAdapter(mAdapter);
            }

            Toast.makeText(getApplicationContext(), getString(R.string.network_error), Toast
                    .LENGTH_LONG).show();
        }

    }

    /**
     * Shows progress dialog.
     * @param message : Message to print on dialog.
     * @return Progress Dialog.
     */
    private ProgressDialog showDialog(String message) {
        ProgressDialog pd = new ProgressDialog(this);
        pd.setCancelable(false);
        pd.setMessage(message);
        pd.show();
        return pd;
    }

    /**
     * Checks if network is avaliable.
     * @return status
     */
    private boolean isNetworkAvailable() {
        ConnectivityManager cm = (ConnectivityManager)
                getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = cm.getActiveNetworkInfo();
        // if no network is available networkInfo will be null
        // otherwise check if we are connected
        if (networkInfo != null && networkInfo.isConnected()) {
            return true;
        }
        return false;
    }

    @Override
    public void contactsDownloaded(List<ContactModel> contactModelList) {
        progressDialog.dismiss();
        if (contactModelList != null && !contactModelList.isEmpty()) {
            mContactModelList = contactModelList;
            mContactModelList = mContactPresenter.processList(mContactModelList);
            mAdapter = new CustomAdapter(mContactModelList, this);
            mRecyclerView.setAdapter(mAdapter);
        } else {
            Toast.makeText(getApplicationContext(), getString(R.string.data_error), Toast
                    .LENGTH_SHORT).show();
        }

    }

    @Override
    public void deleteItemTapped(int position) {
        progressDialog = showDialog(getString(R.string.deleting));
        ContactModel item = mContactModelList.get(position);
        mContactPresenter.deleteContact(mContactModelList, item);
        progressDialog.dismiss();
        mAdapter.notifyDataSetChanged();
        Toast.makeText(getApplicationContext(), getString(R.string.successful), Toast
                .LENGTH_SHORT).show();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ContactsDataSource mySQLiteHelper = SampleApplication.getMySQLiteHelper();
        if(mySQLiteHelper != null ){
            mySQLiteHelper.close();
            SampleApplication.clearSqlHelper();
        }

    }
}
