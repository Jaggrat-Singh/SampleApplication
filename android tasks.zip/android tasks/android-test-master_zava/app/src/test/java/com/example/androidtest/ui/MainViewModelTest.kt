package com.example.androidtest.ui

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import com.example.androidtest.models.ComicDates
import com.example.androidtest.models.ComicIcon
import com.example.androidtest.models.ComicItem
import com.example.androidtest.repo.Repo
import com.nhaarman.mockito_kotlin.mock
import junit.framework.Assert.assertEquals
import org.junit.After
import org.junit.Before
import org.junit.Rule
import org.junit.Test

class MainViewModelTest {

    private lateinit var repo: Repo
    private lateinit var viewModel: MainViewModel

    @get:Rule
    val rule = InstantTaskExecutorRule()

    @Before
    fun setUp() {
        repo = mock()
        viewModel = MainViewModel(repo)
    }

    @After
    fun tearDown() {
    }

    @Test
    fun test_getComic() {
        viewModel.getComicData("comic")
        viewModel.onSuccess(getMockData())

        assertEquals(viewModel.comicLiveData.value?.size, 2)
        assertEquals(viewModel.comicLiveData.value?.get(0)?.title, "first")
        assertEquals(viewModel.comicLiveData.value?.get(0)?.thumbnail, "www.sample.com/1.png")

        assertEquals(viewModel.comicLiveData.value?.get(1)?.title, "second")
        assertEquals(viewModel.comicLiveData.value?.get(1)?.thumbnail, "www.sample.com/2.png")

    }


    @Test
    fun test_process_error() {
        viewModel.onFailure("error")

        assertEquals(viewModel.comicLiveData.value?.size, 1)
        assertEquals(viewModel.comicLiveData.value?.get(0)?.title, "error")
        assertEquals(viewModel.comicLiveData.value?.get(0)?.thumbnail, "NO DATA AVAILABLE")
    }


    /**
     * Mock data
     */
    private fun getMockData(): List<ComicItem> {
        val comicMap: ArrayList<ComicItem> = arrayListOf()
        comicMap.add(
            ComicItem(
                "first", 1,
                arrayListOf(ComicDates("bla", "12-12-12")),
                ComicIcon("www.sample.com/1", "png"),
                arrayListOf(
                    ComicIcon("www.sample.com/1", "png")
                )
            )
        )

        comicMap.add(
            ComicItem(
                "second", 2,
                arrayListOf(ComicDates("bla", "11-11-11")),
                ComicIcon("www.sample.com/2", "png"),
                arrayListOf(
                    ComicIcon("www.sample.com/2", "png")
                )
            )
        )
        return comicMap
    }
}