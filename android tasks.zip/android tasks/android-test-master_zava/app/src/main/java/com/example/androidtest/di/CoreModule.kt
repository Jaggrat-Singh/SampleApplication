package com.example.androidtest.di

import android.content.Context
import com.example.androidtest.BuildConfig
import com.example.androidtest.R
import com.example.androidtest.repo.Repo
import com.example.androidtest.repo.RepoImpl
import com.example.androidtest.repo.UserCache
import com.example.androidtest.rest.RestApi
import com.example.androidtest.utils.md5
import com.google.gson.GsonBuilder
import dagger.Module
import dagger.Provides
import okhttp3.*
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Converter
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory
import java.io.File
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
class CoreModule {

    companion object {
        //https://gateway.marvel.com:443/v1/public/comics?format=comic&apikey=
        private const val BASE_URL = "https://gateway.marvel.com:443/"

        private const val TIMEOUT_CONNECT_IN_SEC = 10

        private const val TIMEOUT_READ_IN_SEC = 15

        private const val TIMEOUT_WRITE_IN_SEC = 15
        private const val cacheSize = (5 * 1024 * 1024).toLong()

    }

    @Provides
    @Singleton
    fun provideRepo(context: Context, restApi: RestApi): Repo {
        return RepoImpl(restApi, provideUserCache(context) )
    }

    @Provides
    @Singleton
    fun provideUserCache(context: Context): UserCache {
        return UserCache(File.createTempFile("comics", null ,context.cacheDir))
    }
    @Singleton
    @Provides
    fun provideRestApi(okHttpClient: OkHttpClient, converter: Converter.Factory): RestApi {
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(converter)
            .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
            .client(okHttpClient)
            .build()
        return retrofit.create(RestApi::class.java)
    }

    @Provides
    @Singleton
    internal fun provideOkHttpClient(context: Context): OkHttpClient {
        val builder = OkHttpClient.Builder()
        val cacheInfo = Cache(context.cacheDir, cacheSize)

        builder.cache(cacheInfo)
                .addInterceptor(httpLoggingInterceptor())
                .addInterceptor(modifyUrlForRequest(context))
                .build()

        builder.connectTimeout(TIMEOUT_CONNECT_IN_SEC.toLong(), TimeUnit.SECONDS)
            .readTimeout(TIMEOUT_READ_IN_SEC.toLong(), TimeUnit.SECONDS)
            .writeTimeout(TIMEOUT_WRITE_IN_SEC.toLong(), TimeUnit.SECONDS)

        return builder.build()
    }


    private fun httpLoggingInterceptor(): Interceptor {
        val logger = HttpLoggingInterceptor()
        if (BuildConfig.DEBUG) {
            logger.level = HttpLoggingInterceptor.Level.BODY
        }
        return logger
    }

    private fun modifyUrlForRequest(context: Context): Interceptor {
        return Interceptor { chain ->
            val cachePolicy = CacheControl.Builder().maxAge(2, TimeUnit.MINUTES).build()
            var originalRequest = chain.request()

            originalRequest = originalRequest.newBuilder().url(modifyUrl(context, originalRequest))
                .removeHeader("Cache-Control")
                .removeHeader("Pragma")
                .header("Cache-Control", cachePolicy.toString())
                .build()
            chain.proceed(originalRequest)
        }
    }


    private fun modifyUrl(context: Context, originalRequest: Request): HttpUrl {
        val originalHttpUrl = originalRequest.url()
        val timeStamp = System.currentTimeMillis().toString()
        val publicKey = context.getString(R.string.public_key)
        val secret = (timeStamp + context.getString(R.string.private_key)+ publicKey).md5()
        val timestampUrl = originalHttpUrl.newBuilder()
            .addQueryParameter("ts", timeStamp)
            .addQueryParameter("apikey", publicKey)
            .addQueryParameter("hash", secret)
            .build()

        return timestampUrl
    }

    @Provides
    internal fun provideGsonConverter(): Converter.Factory = GsonConverterFactory.create(GsonBuilder().create())
}