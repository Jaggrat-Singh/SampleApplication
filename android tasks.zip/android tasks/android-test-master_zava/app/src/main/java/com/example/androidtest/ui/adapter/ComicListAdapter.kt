package com.example.androidtest.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.androidtest.R
import com.example.androidtest.models.ComicInformation
import com.example.androidtest.ui.OnComicTappedListener
import com.example.androidtest.utils.loadImage

class ComicListAdapter(listener: OnComicTappedListener) : RecyclerView.Adapter<ComicListAdapter.ViewHolder>() {
    private val mListener = listener
    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val txtDate: TextView = itemView.findViewById(R.id.tv_comic_title)
        val ivIcon: ImageView = itemView.findViewById(R.id.iv_icon)
    }

    private val comicInfoList = mutableListOf<ComicInformation>()

    override fun getItemCount(): Int = comicInfoList.size

    fun setComicInfoData(list: List<ComicInformation>?) {
        list?.let {
            comicInfoList.clear()
            comicInfoList.addAll(list)
            notifyDataSetChanged()
        }

    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val comicInformation: ComicInformation = comicInfoList[position]
        holder.txtDate.text = comicInformation.title
        holder.ivIcon.loadImage(comicInformation.thumbnail)
        holder.itemView.setOnClickListener { mListener.onItemTapped(comicInformation) }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.list_item, parent, false)
        return ViewHolder(v)
    }
}