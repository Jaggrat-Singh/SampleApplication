package com.example.androidtest.repo

import android.annotation.SuppressLint
import android.util.Log
import com.example.androidtest.models.ComicMap
import com.google.gson.GsonBuilder
import io.reactivex.Observable
import io.reactivex.Single
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit
import javax.inject.Inject


class UserCache @Inject constructor(private val file: File) {

    private val CACHE_LIFE: Long = 2

    /**
     * Deletes cache
     */
    private fun deleteCache() {
        if (file.exists()) {
            file.delete()
            Log.d("jaggrat value", "deleted")
        }
    }

    /**
     * Returns comic map
     * @return : List of comic data
     */
    fun getComicData(): Single<ComicMap> {
        if (file.exists()) {
            val jsonString = FileInputStream(file).bufferedReader().use { it.readText() }
            val builder = GsonBuilder()
            builder.setPrettyPrinting()

            val gson = builder.create()
            if (jsonString.isNotEmpty()) {
                val comicMap = gson.fromJson(jsonString, ComicMap::class.java)
                return Single.just(comicMap)
            }
        }
        return Single.just(ComicMap(arrayListOf()))
    }

    /**
     * Puts data on temp files for 5 minutes.
     * @param values : Comic map.
     */
    fun writeInCache(values: ComicMap) {
        val builder = GsonBuilder()
        val gson = builder.create()
        val jsonString = gson.toJson(values);

        if (!file.exists()) {
            file.createNewFile()
        }

        val inputStream = ByteArrayInputStream(jsonString.toByteArray(Charsets.UTF_8))
        val outputStream = FileOutputStream(file)
        inputStream.use { input ->
            outputStream.use { output ->
                input.copyTo(output)
                deleteCacheAfter(CACHE_LIFE)
            }
        }

    }

    /**
     * Deletes cache after specified time
     * @param value: Cache life.
     */
    @SuppressLint("CheckResult")
    private fun deleteCacheAfter(value: Long) {
        Observable.timer(value, TimeUnit.MINUTES)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe { deleteCache() }
    }

}