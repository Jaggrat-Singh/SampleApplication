package com.example.androidtest.models

data class ApiResponse(
    val data: ComicMap
)

data class ComicMap(
    val results : List<ComicItem>
)

data class ComicItem(
    val title: String,
    val id: Int,
    val dates : List<ComicDates>,
    val thumbnail: ComicIcon,
    val images: List<ComicIcon>
)

data class ComicIcon(val path: String, val extension: String)
data class ComicDates(val type: String, val date: String)

