package com.example.androidtest.utils

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.widget.ImageView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.bumptech.glide.request.RequestOptions
import java.math.BigInteger
import java.security.MessageDigest


fun ImageView.loadImage(url: String?) {
    val placeholder = ColorDrawable(Color.WHITE)
    val requestOptions = RequestOptions
        .placeholderOf(placeholder)
        .fitCenter()
        .optionalCenterCrop()
    Glide.with(this)
        .load(url)
        .apply(requestOptions)
        .transition(DrawableTransitionOptions.withCrossFade())
        .into(this)
}

fun String.md5(): String {
    val md = MessageDigest.getInstance(MD5_ALGO)
    return BigInteger(1, md.digest(toByteArray())).toString(16).padStart(32, '0')
}
