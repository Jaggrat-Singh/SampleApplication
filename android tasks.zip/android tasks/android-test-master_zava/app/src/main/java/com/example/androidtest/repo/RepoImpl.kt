package com.example.androidtest.repo

import android.annotation.SuppressLint
import android.util.Log
import com.example.androidtest.rest.RestApi
import io.reactivex.disposables.Disposable


class RepoImpl(private val restApi: RestApi, private val cache: UserCache) : Repo {

    /**
     * Calls api to get data.
     * @param data: set data in this reference
     * @param type: api end point name
     */
    @SuppressLint("CheckResult")
    override fun getComicData(
        listener: DataDownloadListener,
        type: String
    ): Disposable {
        //rest api automatically adds timestamp, hash and apiKey
        return cache.getComicData()
            .subscribeOn(io.reactivex.schedulers.Schedulers.io())
            .observeOn(io.reactivex.android.schedulers.AndroidSchedulers.mainThread())
            .subscribe({ templates ->
                if(templates == null || templates.results.isEmpty()) {
                    fetchDataFromAPI(listener, type)
                } else {
                    Log.d("jaggrat value ", "cache")
                    val list = templates.results
                    listener.onSuccess(list)
                }

            }, {
                listener.onFailure(it.localizedMessage)
            })
    }


    /**
     * Gets data from API
     */
    private fun fetchDataFromAPI(listener: DataDownloadListener, type: String): Disposable{
        return restApi.getComicDataFromAPI(type)
            .subscribeOn(io.reactivex.schedulers.Schedulers.io())
            .observeOn(io.reactivex.android.schedulers.AndroidSchedulers.mainThread())
            .subscribe({ templates ->
                templates.body()?.data?.let {
                    cache.writeInCache(it)
                }
                Log.d("jaggrat value", "network")
                val list = templates.body()?.data?.results ?: listOf()

                listener.onSuccess(list)
            }, {
                listener.onFailure(it.localizedMessage)
            })
    }
}