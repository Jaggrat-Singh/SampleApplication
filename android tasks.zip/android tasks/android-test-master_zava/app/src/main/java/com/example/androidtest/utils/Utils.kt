package com.example.androidtest.utils

import android.content.Context
import android.icu.util.LocaleData
import android.net.ConnectivityManager
import java.text.DateFormat
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.*

const val DATA_ERROR = "NO DATA AVAILABLE"
const val ERROR_TITLE = "No Data Available. Please try again."
const val MD5_ALGO = "MD5"

/**
 * Checks internet connection
 */
fun verifyAvailableNetwork(activity: Context): Boolean {
    val connectivityManager = activity.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val networkInfo = connectivityManager.activeNetworkInfo
    return networkInfo != null && networkInfo.isConnected
}

/**
 * Converts to string date format
 * @param time: time value
 */
fun String.convertDateFormat(): Date {

    val sdfSource = SimpleDateFormat("yyyy-MM-ddThh:mm:ss")

    val date = sdfSource.parse(this)

    //val sdfDestination = SimpleDateFormat("yyyy-MM-dd")

    //return sdfDestination.format(date)

    return date
}

fun Long.toDateString(dateFormat: Int =  DateFormat.MEDIUM): String {
    val df = DateFormat.getDateInstance(dateFormat, Locale.getDefault())
    return df.format(this)
}


fun convertKtoC(temp: Double): String{
    val df = DecimalFormat("#.##C")
    return df.format(temp.minus( 273.15))
}