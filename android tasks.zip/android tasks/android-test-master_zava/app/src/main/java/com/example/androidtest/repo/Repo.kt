package com.example.androidtest.repo

import io.reactivex.disposables.Disposable

/**
 * Single source of truth for comic data
 */
interface Repo {
    /**
     * First checks data in cache, if not found loads it from sever
     * @param listener : Listener
     * @param type: Type of data
     */
    fun getComicData(
        listener: DataDownloadListener,
        type: String
    ): Disposable
}