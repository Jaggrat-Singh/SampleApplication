package com.example.androidtest.ui

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.androidtest.models.ComicInformation
import com.example.androidtest.models.ComicItem
import com.example.androidtest.repo.DataDownloadListener
import com.example.androidtest.repo.Repo
import com.example.androidtest.utils.DATA_ERROR
import com.example.androidtest.utils.ERROR_TITLE
import com.example.androidtest.utils.convertDateFormat
import io.reactivex.disposables.Disposable
import java.util.*
import javax.inject.Inject
import kotlin.collections.ArrayList

class MainViewModel @Inject constructor(private val repo: Repo) : ViewModel(), DataDownloadListener {
    var comicLiveData: MutableLiveData<List<ComicInformation>> = MutableLiveData()
    private val disposable: ArrayList<Disposable> = arrayListOf();

    /**
     * Returns comic data
     * @param format: Type
     */
    fun getComicData(format: String) {
        disposable.add(repo.getComicData(this, format))
    }


    override fun onFailure(message: String) {
        comicLiveData.value = arrayListOf(ComicInformation(DATA_ERROR, message, -1))
    }

    override fun onSuccess(list: List<ComicItem>) {
        processComicDataIntoInfo(list)
    }



    /**
     * Process comic items into list of comic information
     * @param list: Comic Items
     */
    fun processComicDataIntoInfo(list: List<ComicItem>) {
        val uiModel: List<ComicInformation> = list.map { comicItem ->
            val thumbnailUrl = comicItem.thumbnail.path + "." + comicItem.thumbnail.extension
            ComicInformation(thumbnailUrl, comicItem.title, comicItem.id)
        }


        //set error model if data is null after processing
        if (uiModel.isNullOrEmpty()) {
            comicLiveData.value = arrayListOf(ComicInformation(DATA_ERROR, ERROR_TITLE, -1))
        } else {
            comicLiveData.value = uiModel
        }
    }

    override fun onCleared() {
        super.onCleared()
        disposable.clear()
    }
}