package com.example.androidtest.di

interface Injectable {
}