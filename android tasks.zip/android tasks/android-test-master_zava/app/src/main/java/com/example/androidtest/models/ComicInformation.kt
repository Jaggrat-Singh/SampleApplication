package com.example.androidtest.models

import java.io.Serializable

data class ComicInformation(
    val thumbnail: String,
    val title: String,
    val id: Int
) : Serializable