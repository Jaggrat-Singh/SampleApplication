package com.example.androidtest.repo

import com.example.androidtest.models.ComicItem

interface DataDownloadListener {
    fun onSuccess(list: List<ComicItem>)
    fun onFailure (message: String)
}