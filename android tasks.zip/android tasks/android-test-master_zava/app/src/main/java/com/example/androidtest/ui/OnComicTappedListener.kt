package com.example.androidtest.ui

import com.example.androidtest.models.ComicInformation

/**
 * Comic item tap listener
 */
interface OnComicTappedListener {
    /**
     * Callback for item tap listener
     * @param comicInformation: Information
     */
    fun onItemTapped(comicInformation: ComicInformation)
}