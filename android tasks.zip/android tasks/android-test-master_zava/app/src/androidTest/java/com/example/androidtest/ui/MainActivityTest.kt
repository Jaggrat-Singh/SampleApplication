package com.example.androidtest.ui

import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.*
import androidx.test.espresso.assertion.ViewAssertions.doesNotExist
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.contrib.RecyclerViewActions
import androidx.test.espresso.matcher.ViewMatchers.isDisplayed
import androidx.test.espresso.matcher.ViewMatchers.withId
import androidx.test.rule.ActivityTestRule
import com.example.androidtest.R
import com.example.androidtest.ui.adapter.ComicListAdapter
import org.junit.Rule
import org.junit.Test

class MainActivityTest {
    @get: Rule
    var mActivityRule = ActivityTestRule(MainActivity::class.java)

    @Test
    fun test_get_comic_data_journey(){
        Thread.sleep(3000)
        onView(withId(R.id.recycler_view)).perform(
            RecyclerViewActions.actionOnItemAtPosition<ComicListAdapter.ViewHolder>(0, click()))
        onView(withId(R.id.recycler_view)).check(doesNotExist())
        onView(withId(R.id.tv_comic_title)).check(matches(isDisplayed()))
    }
}